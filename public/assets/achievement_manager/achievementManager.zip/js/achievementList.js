// Path to where you store your achievement icons from root
const achievementIconsPath = "/assets/achievements/";

export const achievements = {
    exampleAchievement: {
        name: "Woah...",
        description: "You did it",
        iconName: `${achievementIconsPath}example-icon.png`
    },
}