import { updateAchievements } from "../achievementManager.js";
import { achievements } from "../achievementList.js"

document.addEventListener("DOMContentLoaded", () => {
    // Access the achievement list and then select the achievement you want to give by key
    updateAchievements(achievements.exampleAchievement);
});